# F1 Dissertation Dashboard

A Streamlit app to explore Formula 1 driver performance using Bayesian modelling and DPI.

---

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```
